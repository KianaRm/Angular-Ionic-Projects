import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: ' com.kianaramzanzadeh.ionicupload',
  appName: 'ionicupload',
  webDir: 'www'
};

export default config;

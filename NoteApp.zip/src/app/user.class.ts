export class User
{
    fullname!:string;
    birthdate!:string;
    email!:string;
    password!:string;

}
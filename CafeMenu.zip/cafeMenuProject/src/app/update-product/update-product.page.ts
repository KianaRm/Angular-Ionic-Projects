import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router, RouterLink } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.page.html',
  styleUrls: ['./update-product.page.scss'],
})
export class UpdateProductPage implements OnInit {
  id:any;
  name: any;
  price:any;
  ingredient: any;
  type: string;

  constructor(private route:ActivatedRoute, private router:Router, private api:ApiService) {
    this.route.params.subscribe((param:any)=>{
      this.id = param.id;
      console.log(this.id);
      this.getProduct(this.id);
    })
   }

  ngOnInit() {
  }

  getProduct(id){
    this.api.getProdut(id).subscribe((res:any)=> {
      console.log("success",res);
      let product = res[0];
      this.name = product.name;
      this.price = product.price;
      this.ingredient = product.ingredient;
      this.type = product.type;
    },(err:any)=>{
      console.log("error",err);
    })
  }

  updateProduct(){
    let data = {
      name: this.name,
      price: this.price,
      ingredient:this.ingredient,
      type: this.type
    }

    this.api.updateProduct(this.id, data).subscribe((res:any)=> {
      console.log("success",res);
      this.router.navigateByUrl('/home');
      this.api.filterProducts(this.type);
    },(err:any)=>{
      console.log("error",err)
    })
  }

  deleteProduct(id){
      this.api.deleteProduct(id).subscribe((res:any)=> {
        console.log("success");
        //alert("Success");
        this.api.getProduts();
        this.router.navigateByUrl('/home');
      },(err:any)=> {
        console.log("error");
      })
  }





}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(public httpClient:HttpClient) { }


  addProduct(data:any){
     return this.httpClient.post('http://localhost/BackEnd/addProduct.php',data);
  }

  getProduts(){
    return this.httpClient.get('http://localhost/BackEnd/getProducts.php')
  }

  getProdut(id){
    return this.httpClient.get('http://localhost/BackEnd/getSingleProduct.php?id='+id);
  }

  updateProduct(id, data) {
    return this.httpClient.put(`http://localhost/BackEnd/updateProduct.php?id=${id}`, data);
  }

  deleteProduct(id){
    return this.httpClient.delete(`http://localhost/BackEnd/deleteProduct.php?id=${id}`)
  }

  filterProducts(type){
    return this.httpClient.get(`http://localhost/BackEnd/filterProducts.php?type=${type}`)
  }

  filterProductsErinc(type){
    return this.httpClient.get(`http://localhost/php-slim-rest-master/slimapp/api/mesajlar/${type}`).pipe(
      map((response: any) => {  console.log("API response", response);})
    );
  }

  signUpUser(data){
    return this.httpClient.post('http://localhost/BackEnd/signUp.php',data);
  }

  signUpUserErinc(data){
    return this.httpClient.post('http://localhost/php-slim-rest-master/slimapp/api/kayit',data);
  } 

   login(data){
    return this.httpClient.post('http://localhost/BackEnd/login.php',data)
  }

  logout(){
    return this.httpClient.get('http://localhost/BackEnd/logout.php')
  }

    /*private apiUrl = 'http://localhost/php-slim-rest-master/slimapp/api';
  
    login(data: any): Observable<any> {
      return this.httpClient.post<any>(`${this.apiUrl}/giris`, data);
    }*/
}

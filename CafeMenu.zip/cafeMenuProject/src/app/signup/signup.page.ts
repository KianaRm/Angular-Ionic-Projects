import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavController ,AlertController, LoadingController, ToastController } from '@ionic/angular';
import { FormBuilder } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../api.service';




@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {

  username: string = '';
  email: string = '';
  password: string = '';
  submitAttempt: boolean = false;

  constructor( public apiService: ApiService, private http: HttpClient,
    private formBuilder: FormBuilder,
    private navCtrl: NavController, private router:Router, private toastCtrl: ToastController, private loadingCtrl:LoadingController, private alertCtrl: AlertController ) {}
      

  ngOnInit() {
  }

  async onSignup() {
    this.submitAttempt = true;

    if (this.username && this.email && this.password) {
      const data = {
        username: this.username,
        email: this.email,
        password: this.password
      };

      this.apiService.signUpUserErinc(data).subscribe(
        async (response: any) => {
          console.log(response)
          if (response.success) {
            const toast = await this.toastCtrl.create({
              message: 'Sign up successful!',
              duration: 2000,
              color: 'green'
            });
            await toast.present();
          } else {
            const toast = await this.toastCtrl.create({
              message: response.message,
              duration: 2000,
            });
            await toast.present();
            this.navCtrl.navigateRoot('/home');
             console.log("dddddd");
          }
        },
        async (error) => {
          console.log(error.error.error)
          const toast = await this.toastCtrl.create({
            message: 'Sign up failed. Please try again later.',
            duration: 2000,
            color: 'danger'
          });
          await toast.present();
        }
      );
    } else {
      const toast = await this.toastCtrl.create({
        message: 'Please fill in all required fields.',
        duration: 2000,
        color: 'danger'
      });
      await toast.present();
    }
  }
}



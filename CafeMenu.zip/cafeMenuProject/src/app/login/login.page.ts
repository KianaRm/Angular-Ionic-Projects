/*import { Component, OnInit } from '@angular/core';
import { NavController, ToastController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../api.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  email: string = '';
  password: string = '';

  constructor(
    private navCtrl: NavController,
    private http: HttpClient,
    private toastController: ToastController,
    public apiService: ApiService
  ) { } 


  async onLogin() {
    if (this.email && this.password) {
      const data = {
        email: this.email,
        password: this.password
      };

      this.apiService.login(data).subscribe(
        async (response: any) => {
          console.log(response)
          if (response.success) {

            this.navCtrl.navigateRoot('/home');
          } else {
            const toast = await this.toastController.create({
              message: response.message,
              duration: 2000,
              color: 'danger'
            });
            await toast.present();
          }
        },
        async (error) => {
          console.error('Login failed:', error);
          const toast = await this.toastController.create({
            message: 'Login failed. Please try again later.',
            duration: 2000,
            color: 'danger'
          });
          await toast.present();
        }
      );
    } else {
      const toast = await this.toastController.create({
        message: 'Please fill in all required fields.',
        duration: 2000,
        color: 'danger'
      });
      await toast.present();
    }
  }

  ngOnInit() {
  }

}*/

import { Component, OnInit } from '@angular/core';
import { NavController, ToastController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  email: string = '';
  password: string = '';

  constructor(
    private navCtrl: NavController,
    private http: HttpClient,
    private toastController: ToastController,
    public apiService: ApiService
  ) { }

  async onLogin() {
    if (this.email && this.password) {
      const data = {
        email: this.email,
        password: this.password
      };

      this.apiService.login(data).subscribe(
        async (response: any) => {
          console.log('Response:', response);
          if (response.success) {
            this.navCtrl.navigateRoot('/home');
          } else {
            const toast = await this.toastController.create({
              message: response.message,
              duration: 2000,
              color: 'danger'
            });
            await toast.present();
          }
        },
        async (error) => {
          console.error('Login failed:', error);
          const toast = await this.toastController.create({
            message: 'Login failed. Please try again later.',
            duration: 2000,
            color: 'danger'
          });
          await toast.present();
        }
      );
    } else {
      const toast = await this.toastController.create({
        message: 'Please fill in all required fields.',
        duration: 2000,
        color: 'danger'
      });
      await toast.present();
    }
  }

  ngOnInit() {
  }
}


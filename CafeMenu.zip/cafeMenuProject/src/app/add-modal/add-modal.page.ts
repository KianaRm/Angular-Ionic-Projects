import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { ApiService } from '../api.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';



@Component({
  selector: 'app-add-modal',
  templateUrl: './add-modal.page.html',
  styleUrls: ['./add-modal.page.scss'],
})
export class AddModalPage implements OnInit {
  
  name: any;
  price:any;
  ingredient: any;
  type: string;


  constructor( public apiService: ApiService, httpClient:HttpClient) { }


  add() {
    let data = {
      name: this.name,
      price: this.price,
      ingredient:this.ingredient,
      type: this.type
    }

    this.apiService.addProduct(data).subscribe((res:any)=> {
      console.log("SUCCESS===",res);
      this.name= "";
      this.price="";
      this.ingredient= "";
      this.type="";
    },(error:any)=> {
      console.log("ERROR",error.error);
    })


  } 

  ngOnInit() {
    

  }

}

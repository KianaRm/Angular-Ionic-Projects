import { Component, ViewChild } from '@angular/core';
import {  ModalController } from '@ionic/angular';
import { AddModalPage } from '../add-modal/add-modal.page';
import { ApiService } from '../api.service';
import { RouterLink } from '@angular/router';
import { NavController, ToastController } from '@ionic/angular';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {



  products: any[] = [];
  filter:any[] = [];        


  constructor(   private navCtrl: NavController,
    private toastController: ToastController,
    private apiService: ApiService) {}

  ngOnInit() {
    this.filterProduct("cold");
  }




  

  getProducts(){
    this.apiService.getProduts().subscribe((res:any)=> {
      console.log("success", res);
      this.products = Object.values(res);
    },(error:any)=>{
      console.log("error", error);
    }) 
  }

  filterProduct(buttonValue: any){
    this.apiService.filterProducts(buttonValue).subscribe((res:any)=> {
      console.log("success", res);
      console.log(res);
      this.filter = res;
    },(error:any)=>{
      console.log("error", error);
    })
  }

  handleRefresh(event) {
    this.filterProduct('cold');
    setTimeout(() => {
      // Any calls to load data go here
      event.target.complete();
    }, 2000);
  }


  async onLogout() {
    this.apiService.logout().subscribe(
      async (response: any) => {
        console.log('Response:', response);
        if (response.success) {
          const toast = await this.toastController.create({
            message: response.message,
            duration: 2000,
            color: 'success'
          });
          await toast.present();
          this.navCtrl.navigateRoot('/login');
        } else {
          const toast = await this.toastController.create({
            message: response.message,
            duration: 2000,
            color: 'danger'
          });
          await toast.present();
        }
      },
      async (error) => {
        console.error('Logout failed:', error);
        const toast = await this.toastController.create({
          message: 'Logout failed. Please try again later.',
          duration: 2000,
          color: 'danger'
        });
        await toast.present();
      }
    );
  }




}

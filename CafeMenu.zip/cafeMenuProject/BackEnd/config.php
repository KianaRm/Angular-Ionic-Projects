<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, DELETE, PUT, PATCH, OPTIONS');
header('Access-Control-Allow-Headers: token, Content-Type');
header('Access-Control-Max-Age: 1728000');
header('Content-Type: application/json');

$connection = new mysqli("localhost", "root", "", "cafe-menu-ionic");

if ($connection->connect_error) {
    die(json_encode(["success" => false, "error" => "Connection failed: " . $connection->connect_error]));
}
?>

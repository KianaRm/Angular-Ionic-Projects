<?php
include "config.php";

$input = file_get_contents('php://input');
$data = json_decode($input, true);
$message = array();
$name = $data['name'];
$price = $data['price'];
$ingredient = $data['ingredient'];
$type = $data['type'];
$id = $_GET['id'];

$q = mysqli_query($connection, "UPDATE `menu` SET `name` = '$name', `price` = '$price', `ingredient` = '$ingredient', `type` = '$type' WHERE `id` = '$id' LIMIT 1;");

if ($q) {
    $message['status'] = "success";
} else {
    http_response_code(442);
    $message['status'] = "Error";
}

echo json_encode($message);
echo mysqli_error($connection);
?>

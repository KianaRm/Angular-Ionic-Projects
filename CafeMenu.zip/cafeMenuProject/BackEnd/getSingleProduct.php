<?php
include "config.php";

$data = array();
$id = $_GET['id'];

$q = mysqli_query($connection, "SELECT * FROM `menu` WHERE `id` = $id LIMIT 1");

if ($q) {
    while ($row = mysqli_fetch_object($q)) {
        $data[] = $row;
    }

    header('Content-Type: application/json');
    echo json_encode($data);
} else {
    echo json_encode(array("error" => mysqli_error($connection)));
}

?>

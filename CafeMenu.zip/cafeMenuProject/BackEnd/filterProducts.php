<?php
include "config.php";

$data = array();

$type = mysqli_real_escape_string($connection, $_GET['type']);

// Debug: Log the type received
error_log("Received type: $type");

$q = mysqli_query($connection, "SELECT * FROM `menu` WHERE `type` = '$type'");

// Debug: Check if the query executed successfully
if (!$q) {
    error_log("Query error: " . mysqli_error($connection));
}

if ($q) {
    while ($row = mysqli_fetch_object($q)) {
        $data[] = $row;
    }

    header('Content-Type: application/json');
    echo json_encode($data); // Ensure this outputs the correct JSON
} else {
    echo json_encode(array("error" => mysqli_error($connection)));
}
?>

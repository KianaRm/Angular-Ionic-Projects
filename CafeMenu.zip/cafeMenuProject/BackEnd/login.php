<?php
include "config.php";
header("Content-Type: application/json");

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (is_null($data)) {
    die(json_encode(["error" => "Invalid JSON payload"]));
}


$email = isset($data['email']) ? $data['email'] : null;
$password = isset($data['password']) ? $data['password'] : null;

if (empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit();
}

$stmt = $conn->prepare('SELECT * FROM users WHERE email = ?');
if (!$stmt) {
    error_log('Prepare failed: ' . $conn->error);
    echo json_encode(['success' => false, 'message' => 'Failed to prepare statement.']);
    exit();
}

$stmt->bind_param('s', $email);
if (!$stmt->execute()) {
    error_log('Execute failed: ' . $stmt->error);
    echo json_encode(['success' => false, 'message' => 'Login failed. Please try again later.']);
    exit();
}

$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Email not found.']);
    exit();
}

$user = $result->fetch_assoc();
if (!password_verify($password, $user['password'])) {
    echo json_encode(['success' => false, 'message' => 'Incorrect password.']);
    exit();
}

echo json_encode(['success' => true]);
$stmt->close();
$conn->close();
?>






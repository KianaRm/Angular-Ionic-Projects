<?php
include "config.php";
header("Content-Type: application/json");

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (is_null($data)) {
    die(json_encode(["error" => "Invalid JSON payload"]));
}

$username = isset($data['username']) ? $data['username']: null;
$email = isset($data['email']) ? $data['email'] : null;
$password = isset($data['password']) ? $data['password']: null;

if (empty($username) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit();
}

$email = filter_var($email, FILTER_VALIDATE_EMAIL);
if (!$email) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address.']);
    exit();
}

$passwordHash = password_hash($password, PASSWORD_BCRYPT);

$stmt = $conn->prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)');
$stmt->bind_param('sss', $username, $email, $passwordHash);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to create user.']);
}

$stmt->close();
$conn->close();






?>
<?php

include'config.php';
header("Content-Type: application/json");
$input = file_get_contents("php://input");
$data = json_decode($input,true);
if (is_null($data)) {
    die(json_encode(["error" => "Invalid JSON payload"]));
}

$name = isset($data['name']) ? $data['name'] : null;
$price = isset($data['price']) ? $data['price'] : null;
$ingredient = isset($data['ingredient']) ? $data['ingredient'] : null;
$type = isset($data['type']) ? $data['type'] : null;

if (is_null($name) || is_null($price) || is_null($ingredient) || is_null($type)) {
    die(json_encode(["error" => "Missing required fields"]));
}


$q = mysqli_query($connection, "INSERT INTO `menu` (`name`,`price`,`ingredient`,`type`) VALUES ('$name','$price','$ingredient','$type')");

if($q){
    http_response_code(201);
    $message['status'] = "success";
}else{
    http_response_code(442);
    $message['status'] = "Error";
}

echo json_encode($message);
echo mysqli_error($connection);





?>